package com.capgemini.capstore.controller;

import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

@Controller
public class OrderPlacedController {

	@RequestMapping("/placeorder")
	String placeorder(ModelMap map) {
		System.out.println("IN CLIENT place order");
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/orderplaced",ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT place order:"+response);
		return "placedproduct";
	}
	
}
