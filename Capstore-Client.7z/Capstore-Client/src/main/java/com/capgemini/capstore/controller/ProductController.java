package com.capgemini.capstore.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;


@Controller
public class ProductController {
	
	
	@RequestMapping("/")
	public String homePage(ModelMap map) {
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/capstore",ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT:"+response);
		return "index";
		
	}
	@RequestMapping("/sortl")
	public String sortbylowtohigh( ModelMap map) {
		System.out.println("IN CLIENT Sort LOW");
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/findbylowtohigh",ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT sort low:"+response);
		return "index";
	}
	
	@RequestMapping("/sorth")
	public String sortbyhightoloww( ModelMap map) {
		System.out.println("IN CLIENT Sort High");
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/findbyhightoLow",ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT sort high:"+response);
		return "index";
	}
	@RequestMapping("/sortll")
	public String sortbylowtohighh( ModelMap map) {
		System.out.println("IN CLIENT Sort LOW");
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/findbylowtohigh",ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT sort low:"+response);
		return "customer-homepage";
	}
	
	@RequestMapping("/sorthh")
	public String sortbyhightolow( ModelMap map) {
		System.out.println("IN CLIENT Sort High");
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/findbyhightoLow",ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT sort high:"+response);
		return "customer-homepage";
	}
	@RequestMapping("/searching")
	public String search( ModelMap map,@RequestParam("search") String searching) {
		System.out.println("IN CLIENT search for customer");
		System.out.println("after sign up"+searching);
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/search/"+searching,ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT search for customer:"+response);
		return "customer-homepage";
	}
	@RequestMapping("/searchingg")
	public String searchh( ModelMap map,@RequestParam("search") String searching) {
		System.out.println("IN CLIENT search");
		
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/search/"+searching,ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT sort high:"+response);
		return "index";
	}
	@RequestMapping("/sign-in-as-customer")
	String signInAsCustomer( ModelMap map) {
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/capstore",ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT after sign up:"+response);	
		return "customer-homepage";
	}
	@RequestMapping("/single")
	public String individualProduct(HttpServletRequest request, ModelMap map) {
		int prodid=Integer.parseInt(request.getParameter("id"));
		
		/*
		 * System.out.println("Inside singlee:"+prodid); List<Product>
		 * list=repo.single(prodid); map.addAttribute("product",list);
		 * System.out.println("In controller single :"+list); return "single";
		 */
		System.out.println("client id:"+prodid);
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/single/"+prodid,ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT single:"+response);	
		return "single";
	}
	@RequestMapping("/singlee")
	public String individualProductAfterSignUp(HttpServletRequest request, ModelMap map) {
		int prodid=Integer.parseInt(request.getParameter("id"));
		
		/*
		 * System.out.println("Inside singlee:"+prodid); List<Product>
		 * list=repo.single(prodid); map.addAttribute("product",list);
		 * System.out.println("In controller single :"+list); return "single";
		 */
		System.out.println("client id:"+prodid);
		RestTemplate restTemplate = new RestTemplate(); 
		ArrayList response = restTemplate.getForObject("http://localhost:9999/single/"+prodid,ArrayList.class);
		map.addAttribute("product",response);
		System.out.println("IN CLIENT single:"+response);	
		return "single";
	}
	@RequestMapping("/about")
	String loadAbout(ModelMap modal) {
		return "about";
	}
	
	
	@RequestMapping("/cart")
	String addtocart(ModelMap modal) {
		return "cart";
	}
	
	@RequestMapping("/wishlist")
	String addtowishlist(ModelMap modal) {
		return "wishlist";
	}
	
	
	
	
	
	
	
	
	
}
