package com.capgemini.CapstoreBack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.CapstoreBack.Repository.IOrderPlacedRepository;
import com.capgemini.CapstoreBack.bean.CartDTO;

@Service
public class OrderPlacedService implements IOrderPlacedService {
	
	@Autowired
	IOrderPlacedRepository repo;

	@Override
	public List<CartDTO> getOrderPlacedProduct() {
		// TODO Auto-generated method stub
		return repo.getOrderPlacedProduct();
	}

}
