package com.capgemini.CapstoreBack.bean;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Response {
	@JsonProperty
	private Product product;
	public Response() {
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	public Response(Product product) {
		this.product = product;
	}
	@Override
	public String toString() {
		return "Response [product=" + product + ", getProduct()=" + getProduct() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
	}
	


}

