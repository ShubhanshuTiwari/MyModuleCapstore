package com.capgemini.CapstoreBack.service;

import java.util.List;

import com.capgemini.CapstoreBack.bean.CartDTO;


public interface IOrderPlacedService {

	public List<CartDTO> getOrderPlacedProduct();
}
