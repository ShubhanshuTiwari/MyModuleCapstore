package com.capgemini.CapstoreBack.Repository;

import java.util.List;

import com.capgemini.CapstoreBack.bean.CartDTO;


public interface IOrderPlacedRepository {
	public List<CartDTO> getOrderPlacedProduct();

}
