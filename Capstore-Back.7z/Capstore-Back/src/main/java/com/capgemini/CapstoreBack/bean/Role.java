package com.capgemini.CapstoreBack.bean;

public enum Role {
	Customer,Admin,Merchant
}
