package com.capgemini.CapstoreBack.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.CapstoreBack.Repository.IProductRepository;
import com.capgemini.CapstoreBack.bean.Product;
@Service
public class ProductService implements IProductService{

	@Autowired
	IProductRepository prodRepo;
	@Override
	public List<Product> getProduct() {
		// TODO Auto-generated method stub
		return prodRepo.getProduct();
	}
	@Override
	public List<Product> sortPriceLowToHigh() {
		// TODO Auto-generated method stub
		return prodRepo.sortPriceLowToHigh();
	}
	@Override
	public List<Product> sortPriceHighToLow() {
		// TODO Auto-generated method stub
		return prodRepo.sortPriceHighToLow();
	}
	@Override
	public List<Product> getSearch(String search) {
		// TODO Auto-generated method stub
		return prodRepo.getSearch(search);
	}
	@Override
	public List<Product> single(int idd) {
		// TODO Auto-generated method stub
		return prodRepo.single(idd);
	}

}
