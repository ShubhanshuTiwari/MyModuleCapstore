package com.capgemini.CapstoreBack.bean;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
public class HelloBean {
	@Id
	String msg;

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public HelloBean() {
	}

	public HelloBean(String msg) {
		this.msg = msg;
	}
	
	@Override
	public String toString() {
		return "HelloBean [msg=" + msg + "]";
	}
	
}
