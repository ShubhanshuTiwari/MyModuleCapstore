package com.capgemini.CapstoreBack.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.CapstoreBack.bean.CartDTO;
import com.capgemini.CapstoreBack.service.IOrderPlacedService;

@RestController
public class OrderPlacedController {

	@Autowired
	IOrderPlacedService service;
	@RequestMapping(value="/orderplaced")
	public List<CartDTO> orderPlaced(){
		return service.getOrderPlacedProduct();
		
	} 
	
}
