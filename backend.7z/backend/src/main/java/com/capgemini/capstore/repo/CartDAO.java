package com.capgemini.capstore.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capgemini.capstore.dto.CartDTO;
import com.capgemini.capstore.dto.Customer;



public interface CartDAO extends JpaRepository<CartDTO, Integer>
{
	
	@Query("select cart from CartDTO cart where cart.customer = :customer")
	List<CartDTO> getCartDetailsOfSpecificCustomer(@Param("customer") Customer customer);
}