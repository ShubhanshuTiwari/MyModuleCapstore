package com.example.democlient.boot.controller;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.democlient.boot.beans.User;

@Repository
@Transactional
public class DaoReference {
	
	@PersistenceContext
	private EntityManager em;
	
	
	
	public User Add(String Email,String newPass)
	{
		User usr = em.find(User.class, Email);
		usr.setPassword(newPass);
		return usr;
	}
	
	
	

}
