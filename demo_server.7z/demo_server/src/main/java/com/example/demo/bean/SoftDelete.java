package com.example.demo.bean;

public enum SoftDelete {
	Activated, Deactivated
}
