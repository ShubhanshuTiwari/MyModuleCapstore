package com.example.demo.bean;

public enum Category {
	Electronics, Clothing, FootWear, Grocery, Cosmetics,Sports
}
