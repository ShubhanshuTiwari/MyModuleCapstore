package com.example.demo.repo;

import com.example.demo.bean.Admin;
import com.example.demo.bean.Customer;
import com.example.demo.bean.Merchant;
import com.example.demo.bean.User;






//Follow TODOs (if available)
/**
 * 
 * This is a CarDAO class
 * @see java.lang.Object
 * @author Abhishek
 * 
 *
 */
public interface userDAO 
{
    public void createCustomer(Customer user);
	public void createMerchant(Merchant mer);
	public User validateUser(User user);
	public void createUser(User user);
	public Admin getAdminByEmail(String email);
	public Merchant getMerchantByEmail(String email);
	public Customer getCustomerByEmail(String email);
	public void changePassword(User user);
	public String forgetEmail(String email);

}